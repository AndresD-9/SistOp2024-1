/*
Codigo de trabajo 1 Seccion: 411
Integrantes:
    Daniel Martinez Lefian, 21086530-6
    Danko Lobos Bustamante, 19307134-1
    Rodrigo Sánchez Calderon, 19514594-6
    Sebastian Inzulza Sepulveda,18749984-4
    Daniel Palacios Gomez, 19733454-1
Instrucciones: Ingrese el nombre y extension del archivo y pulse comenzar, el archivo
debe estar en la ubicacion del .exe
*/
#include <Windows.h>
#include <string>
#include <vector>
#include <thread>
#include <chrono>
#include <fstream>
#include <sstream>
#include <mutex>

using namespace std;

vector<string> interrupciones;
mutex mtx;

void modo_kernel(const string& direccion, const vector<int>& rutinas, int& modo, int& PC, HWND hStatic) {
    modo = 1;
    --PC;
    wstringstream wss;
    wss << L"PC: " << PC << L", Modo bit: " << modo << L" ";

    mtx.lock();
    interrupciones.push_back(direccion);
    mtx.unlock();

    size_t pos = interrupciones.size() - 1;
    wss << L", Delay: ";
    for (int j = 0; j < rutinas[pos]; ++j) {
        this_thread::sleep_for(chrono::seconds(1));
        wss << j + 1 << L"...";
    }
    wss << L"\n";
    modo = 0;

    int length = GetWindowTextLengthW(hStatic);
    wchar_t* buffer = new wchar_t[length + 1];
    GetWindowTextW(hStatic, buffer, length + 1);

    wstringstream new_wss;
    new_wss << buffer << wss.str();

    SetWindowTextW(hStatic, new_wss.str().c_str());

    delete[] buffer;
    ++PC;
}

void ProcessFile(HWND hStatic1, HWND hStatic2, HWND hStatic3, HWND hStatic4, HWND hStatic5) {
    //-------------------------------------------------------------------
    int length2 = GetWindowTextLength(hStatic3);
    if (length2 == 0) {
        // Si no hay texto en el control
        MessageBox(NULL, L"No se introdujo ningun nombre de archivo!", L"Error", MB_OK | MB_ICONERROR);
        return;
    }
    wchar_t* buffer2 = new wchar_t[length2 + 1];
    GetWindowText(hStatic3, buffer2, length2 + 1); // Obtener el texto
    wstring fileAddress(buffer2);
    delete[] buffer2;
    //-------------------------------------------------------------------
    ifstream archivo(fileAddress);
    ofstream archivoSalida(L"archivo_parche.txt");
    //-------------------------------------------------------------------
    string clave = "write";
    string linea = "";
    //-------------------------------------------------------------------
    int modo = 0;
    int PC = 1;
    //-------------------------------------------------------------------
    vector<int> rutinas(10);
    //-------------------------------------------------------------------
    for (int i = 0; i < 10; ++i) {
        rutinas[i] = i + 1;
    }
    //-------------------------------------------------------------------
    if (!archivo) {
        MessageBox(NULL, L"No se pudo abrir el archivo!", L"Error", MB_OK | MB_ICONERROR);
        return;
    }
    //-------------------------------------------------------------------
    while (getline(archivo, linea)) {
        wstringstream wss;
        if (linea.compare(0, clave.length(), clave) == 0) {
            string despuesClave = linea.substr(clave.length());
            size_t posInicioTexto = despuesClave.find_first_not_of("(");
            size_t posFinTexto = despuesClave.find_first_of(")") - 1;
            if (posInicioTexto != string::npos) {
                string direccion = despuesClave.substr(posInicioTexto, posFinTexto);
                modo_kernel(direccion, rutinas, modo, PC, hStatic1);
            }
            else {
                wss << L"Palabra clave no incluye dirección\n";
                int length = GetWindowTextLengthW(hStatic1);
                wchar_t* buffer = new wchar_t[length + 1];
                GetWindowTextW(hStatic1, buffer, length + 1);

                wstringstream new_wss;
                new_wss << buffer << wss.str();

                SetWindowTextW(hStatic1, new_wss.str().c_str());
                delete[] buffer; // Liberar memoria del buffer
            }
        }
        else {    
            wss << L"PC: " << PC << L", Modo bit: " << modo << L"\n";
                //<< L" , No se encontro clave\n";
            for (int j = 0; j < 1; ++j) {
                this_thread::sleep_for(chrono::seconds(1));
            }

            int length = GetWindowTextLengthW(hStatic2);
            wchar_t* buffer = new wchar_t[length + 1];
            GetWindowTextW(hStatic2, buffer, length + 1);

            wstringstream new_wss;
            new_wss << buffer << wss.str();

            SetWindowTextW(hStatic2, new_wss.str().c_str());
            delete[] buffer;
            ++PC;
        }
        linea += "*";
        archivoSalida << linea << endl;
    }

    wstringstream wss3;
    wss3 << L"Codigos de interrupciones: ";
    mtx.lock();
    for (const auto& interrupcion : interrupciones) {
        this_thread::sleep_for(chrono::seconds(1));
        wss3 << "(" << interrupcion.c_str() << ")";
    }
    mtx.unlock();

    int length = GetWindowTextLengthW(hStatic1);
    wchar_t* buffer = new wchar_t[length + 1];
    GetWindowTextW(hStatic5, buffer, length + 1);

    wstringstream new_wss2;
    new_wss2 << buffer << wss3.str();

    SetWindowTextW(hStatic5, new_wss2.str().c_str());
    delete[] buffer;

    archivo.close();

    archivoSalida.close();

    if (_wremove(fileAddress.c_str()) != 0) {
        MessageBox(NULL, L"No se pudo eliminar el archivo original!", L"Error", MB_OK | MB_ICONERROR);
        return;
    }

    if (_wrename(L"archivo_parche.txt", fileAddress.c_str()) != 0) {
        MessageBox(NULL, L"No se pudo renombrar el archivo de salida!", L"Error", MB_OK | MB_ICONERROR);
    }
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    static HWND hButton;
    static HWND hStatic1, hStatic2, hStatic3, hStatic4, hStatic5;

    switch (uMsg) {
    case WM_CREATE:
        hButton = CreateWindow(
            L"BUTTON",
            L"Start",
            WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
            10,         // x
            10,         // y
            100,        // ancho
            30,         // alto
            hwnd,
            (HMENU)1,
            (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
            NULL);
        hStatic4 = CreateWindow(
            L"STATIC",
            NULL,
            WS_CHILD | WS_VISIBLE | SS_SIMPLE,
            120,        // x
            10,        // y
            260,       // ancho
            35,       // alto
            hwnd, (HMENU)4, (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), NULL);

        hStatic1 = CreateWindow(
            L"STATIC",
            NULL,
            WS_CHILD | WS_VISIBLE | WS_BORDER | SS_LEFT,
            10,        // x
            135,        // y
            370,       // ancho
            205,       // alto
            hwnd, (HMENU)2, (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), NULL);

        hStatic2 = CreateWindow(
            L"STATIC",
            NULL,
            WS_CHILD | WS_VISIBLE | WS_BORDER | SS_LEFT,
            10,        // x
            350,        // y
            370,       // ancho
            240,       // alto
            hwnd, (HMENU)3, (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), NULL);

        hStatic3 = CreateWindow(
            L"EDIT",
            NULL,
            WS_CHILD | WS_VISIBLE | WS_BORDER | SS_LEFT,
            10,        // x
            50,        // y
            370,       // ancho
            30,       // alto
            hwnd, (HMENU)4, (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), NULL);
        
        hStatic5 = CreateWindow(
            L"STATIC",
            NULL,
            WS_CHILD | WS_VISIBLE | WS_BORDER | SS_LEFT,
            10,        // x
            90,        // y
            370,       // ancho
            30,       // alto
            hwnd, (HMENU)3, (HINSTANCE)GetWindowLongPtr(hwnd, GWLP_HINSTANCE), NULL);

        SetWindowTextW(hStatic4, L"Ingrese nombre y extension del archivo");
        break;

    case WM_COMMAND:
        if (LOWORD(wParam) == 1) {
            ProcessFile(hStatic1, hStatic2, hStatic3, hStatic4, hStatic5);
        }
        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;

    case WM_SETTEXT:
        return 0;

    default:
        return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }

    return 0;
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE, PWSTR pCmdLine, int nCmdShow) {
    const wchar_t CLASS_NAME[] = L"Sample Window Class";

    WNDCLASS wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;

    RegisterClass(&wc);

    HWND hwnd = CreateWindowEx(
        0,
        CLASS_NAME,
        L"Ejecucion de interrupciones",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 410, 650,
        NULL,
        NULL,
        hInstance,
        NULL
    );

    if (hwnd == NULL) {
        return 0;
    }

    ShowWindow(hwnd, nCmdShow);

    MSG msg = {};
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}
